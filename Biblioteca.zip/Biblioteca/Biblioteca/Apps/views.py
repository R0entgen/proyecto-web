from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import * #Importamos los modelos
from django.views.generic import TemplateView, ListView, UpdateView
from django.views.generic.edit import FormView, CreateView, DeleteView
from django.http.response import HttpResponseRedirect
from django.core.urlresolvers import reverse_lazy
from django.contrib.auth import login, authenticate, logout
from .forms import LoginForm
from .htmltopdf import render_to_pdf

# Create your views here.

class Login(FormView):
    #Establecemos la plantilla a utilizar
    template_name = 'inicio.html'
    #Le indicamos que el formulario a utilizar es el formulario de autenticacion de Django
    form_class = LoginForm
    #Le decimos que cuando se haya completado exitosamente la operacion nos redireccione a la url bienvenida de la aplicacion personas
    success_url = "/libro/"

    def form_valid(self,form):
        user = authenticate(username= form.cleaned_data['username'], 
                password = form.cleaned_data['password'])
        if(user is not None):
            if(user.is_active):
                login(self.request, user)
        return super(Login,self).form_valid(form)

def LogOut(request):
    logout(request)
    return redirect("/")

def busqueda(self):
   q = request.GET.get('q', '')

   querys = (Q(libro__icontains=q) | Q(categorias_icontains=q))
   querys |= Q(autor__icontains=q)

   libro = Evento.objects.filter(querys)
   return render(request, 'busqueda.html', {'libro': libro})

class LibroView(ListView):
    
    model = Libro

    template_name = 'libros.html'

    context_object_name = 'Categoria'

class CreateLibroView(CreateView):

    model = Libro

    template_name = 'creado.html'

    success_url = '/libro/'

    fields = ['simbologia','titulo_Libro','Nombre_del_Autor', 'edicion', 'categoria_id']

class DeleteLibroView(DeleteView):

    model = Libro

    template_name= 'delete.html'

    success_url = '/libro/'

class EditLibroView(UpdateView):

    model= Libro

    template_name='edit.html'
    
    success_url='/libro/'
    
    fields = ['simbologia','titulo_Libro','Nombre_del_Autor', 'edicion', 'categoria_id']

class PrestamoView(CreateView):
    
    model= Persona, Libro
    
    template_name='creado.html'
    
    success_url='/libro/'

    def pregunta(form_valid):
        
        if(model==Alumno):
            fields = ['cedula','nombre','fecha_nacimiento','carrera','semestre']

        elif(model==Profesor):
            fields = ['cedula','nombre','fecha_nacimiento','dedicacion']


def pdf(request):
    return render_to_pdf('reporte.html', {'title': ' Reportes de Prestamo'})

