from __future__ import unicode_literals

from django.db import models

import time


class Alumno(models.Model):
	
	cedula = models.IntegerField(primary_key=True, null=False, blank=False)
	
	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")
	def __unicode__(self):#__str__ para python 3
		return self.nombre


class Categorias(models.Model):

	nombre = models.CharField(max_length=20)
	def __unicode__(self):#__str__ para python 3
		return self.nombre


class Edicion(models.Model):

	nombre = models.CharField(max_length=10)
	def __unicode__(self):#__str__ para python 3
		return self.nombre


class Autor(models.Model):
	
	nombre = models.CharField(max_length=50)
	
	categoria_id = models.ForeignKey(Categorias)

	def __unicode__(self):#__str__ para python 3
		return self.nombre


class Libro(models.Model):

	simbologia = models.CharField(primary_key=True, max_length=20)## es max_length no max_lenght
	
	titulo_Libro = models.CharField(max_length=100)
	
	autor_id = models.ForeignKey(Autor)##definicion de many2one relacion
	
	Nombre_del_Autor = models.CharField(max_length=50)
	
	categoria_id = models.ForeignKey(Categorias)

	edicion_id = models.ForeignKey(Edicion)

	def __unicode__(self):#__str__ para python 3
		return self.titulo_Libro


	
class Profesor(models.Model):

	cedula = models.IntegerField(primary_key=True, null=False, blank=False)

	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")

	dedicacion = models.CharField(max_length=2)
	
	def __unicode__(self):#__str__ para python 3
		return self.nombre



class Visitante(models.Model):

	cedula = models.IntegerField(primary_key=True, null=False, blank=False)

	nombre = models.CharField(max_length=50)
	
	fecha_nacimiento = models.DateField("Fecha De Nacimiento")

	def __unicode__(self):#__str__ para python 3
		return self.nombre


class Usuarios(models.Model):

	usuario=models.TextField(unique=True)
	
	password=models.TextField()

