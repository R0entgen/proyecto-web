from django.conf.urls import *

from Biblioteca.Apps.views import Login, LibroView, LogOut, CreateLibroView#Le decimos a Django que de este directorio importe el fichero views



urlpatterns = [  
    
    url( r'^$' , Login.as_view(), name= 'Login' ),
    url(r'^agregar/$', CreateLibroView.as_view(), name = 'agregar'),
    url( r'^libro/$', LibroView.as_view(), name='Libro'),
    url( r'^logout/$', LogOut)
    
    
#Le decimos a Django que de este directorio importe el fichero views
]
