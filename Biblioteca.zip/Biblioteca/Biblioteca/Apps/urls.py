from django.conf.urls import *

from Biblioteca.Apps.views import *#Le decimos a Django que de este directorio importe el fichero views



urlpatterns = [  
    
    url( r'^$' , Login.as_view(), name= 'Login' ),
    
    url( r'^libro/$', LibroView.as_view(), name='Libro'),
    url( r'^buscar/$', LibroView.as_view(), name='buscar'),
    url( r'^persona/$', PersonaView.as_view(), name='persona'),
    url( r'^editar/(?P<pk>[-\w.]+)/$', EditLibroView.as_view(), name = 'editar'),
   	url( r'^editar_persona/(?P<pk>[-\w.]+)/$', EditPersonaView.as_view(), name = 'editar_persona'),
    url( r'^agregar/$', CreateLibroView.as_view(), name = 'agregar'),
    url( r'^registro_visita/$', RegistroView.as_view(), name = 'registro'),
    url( r'^borrar/(?P<pk>[-\w.]+)/$', DeleteLibroView.as_view(), name='borrar'),
    url( r'^borrar_persona/(?P<pk>[-\w.]+)/$', DeletePersonaView.as_view(), name='borrar'),
    url( r'^logout/$', LogOut)
    
]
