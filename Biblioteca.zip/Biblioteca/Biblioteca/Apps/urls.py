from django.conf.urls import *

from Biblioteca.Apps.views import Login, LibroView, LogOut, CreateLibroView, DeleteLibroView, EditLibroView, PrestamoView, pdf#Le decimos a Django que de este directorio importe el fichero views



urlpatterns = [  
    
    url( r'^$' , Login.as_view(), name= 'Login' ),
    url( r'^libro/$', LibroView.as_view(), name='Libro'),
    #url( r'^reporte/(?P<slug>[-?\w]+)/$', PrestamoView.views.pdf, name='reporte'),
    url( r'^agregar/$', CreateLibroView.as_view(), name = 'agregar'),
    url( r'^editar/(?P<pk>\w.+)/$', EditLibroView.as_view(), name = 'editar'),
    url( r'^borrar/(?P<pk>\w.+)/$', DeleteLibroView.as_view(), name='borrar'),
    url( r'^logout/$', LogOut)
    
]
