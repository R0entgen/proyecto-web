#importamos la api forms desde django
from django import forms 
from django.forms import ModelForm

#Importamos los modelos, por ahora solo Libro
from .models import Libro

class FormCrearLibro(forms.ModelForm):
	"""Clase para crear un formulario 
	a partir de un modelo definido"""
	class Meta:
		"""Clase interna, aca definimos la informacion necesaria:
		1. de que modelo es el form a costruir (variable model)
		2. cuales campos tendra el formulario (variable fields)"""
		model = Libro
		fields = ['titulo', 'autores', 'editor', 'fecha_publicacion', 'portada', 'sinopsis']