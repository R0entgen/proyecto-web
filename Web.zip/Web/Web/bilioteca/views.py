# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

from django.http import HttpResponse
# Create your views here.
from .models import Editor, Autor, Libro

#...another imports 
#importamos las vistas genericas de Django para crear, actualizar y eliminar
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .forms import FormCrearLibro #luego veremos para que 
from django.core.urlresolvers import reverse_lazy


def books(request):
	all_books = Libro.objects.all()
	context = {'object_list':all_books}
	return render('templates/biblioteca/allbooks.html', context)

def detail_book(request, id_book):
	book = Libro.objects.get(id=id_book)
	context = {'object':book}
	return render(request, 'templates/biblioteca/detailbook.html', context)


class LibroCreateView(CreateView):
	"""Con esta vista generica, tenemos la logica
	para crear un nuevo Libro"""	
	model = Libro
	#Caracteristicas especiales para el form de crear
	form_class = FormCrearLibro
	template_name = 'templates/biblioteca/uc_libro.html'

class LibroUpdateView(UpdateView):
	"""Esta vista nos permite actualizar un Libro existente"""
	model = Libro
	form_class = FormCrearLibro
	template_name = 'templates/biblioteca/uc_libro.html'	


class LibroDeleteView(DeleteView):
	"""Esta vista nos permitira eliminar un Libro existente"""
	model = Libro
	success_url = reverse_lazy('sitio:index')